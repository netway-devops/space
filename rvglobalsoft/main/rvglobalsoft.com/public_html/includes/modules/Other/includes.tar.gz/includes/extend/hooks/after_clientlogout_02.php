<?php 
#@LICENSE@#
?>
<?php
/**
 * Client with ID=$details just logged out
 * Following variable is available to use in this file:  $details client id in HostBill
 */
$_SESSION['myVIPSession'] = '';