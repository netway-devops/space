<?php

/*************************************************************
 *
 * Hosting Module Class - symantecvip
 * 
 * http://dev.hostbillapp.com/dev-kit/provisioning-modules/admin-area/
 * http://dev.hostbillapp.com/dev-kit/advanced-topics/hostbill-controllers/
 * 
 * 
 ************************************************************/

// Load SymantecvipDAO
include_once(APPDIR_MODULES . "Hosting/symantecvip/include/api/class.symantecvip.dao.php");

class symantecvip_controller extends HBController {
	
	//protected $UploadCerPath = "/home/isara/public_html/rvglobalsoft.com/public_html/upload/certificate_file/";
	//protected $UploadCerUrl = "http://192.168.1.92/rvglobalsoft.com/public_html/upload/certificate_file/";
	protected $UploadCerPath;
	protected $UploadCerUrl;
	
	/**
	 * 
	 * Enter description here ...
	 * @param $request
	 */
	public function view($request) {
	}
	
	
	/**
	 * 
	 * Enter description here ...
	 * @param $params
	 */
    public function accountdetails($params) {
    	
    	$this->UploadCerPath = MAINDIR . "upload/certificate_file/";
    	$this->UploadCerUrl = system_url . "upload/certificate_file/";
    	
    	$symantecVipTabs = APPDIR_MODULES . "Hosting/" . $this->getModuleName() . "/templates/AdminSymantecvip.tpl";
        $this->template->assign("symantecviptabs", $symantecVipTabs);
        
        //echo "param=<pre>";
        //print_r($params);
       
        $vipData = SymantecvipDao::singleton()->getVIPInfoByUsrID($params['account']['client_id']);
        
        $vipQty = SymantecvipDao::singleton()->getSymantecVipAccount($params['account']['id']);
        
        if ($vipData['vip_info_id'] != '') {
        	
        	$this->template->assign("vip_info_id", $vipData['vip_info_id']);
        	$this->template->assign("vip_info_type_text", $vipData['vip_info_type']);
        	$this->template->assign("vip_subscription_status", $vipData['vip_subscription_status']);
        	$this->template->assign("vip_manage_status", $vipData['vip_manage_status']);
        	
        	//========= step 1. ou and quantity
        	$this->template->assign("vip_ou_number", $vipData['ou_number']);
        	$this->template->assign("quantity", $vipQty);
        	$this->template->assign("quantity_at_symantec", $vipData['quantity_at_symantec']);
        	$this->template->assign("symantec_connection", $vipData['symantec_connection']);
        	
        	
        	
        	if ($vipData['certificate_expire_date'] > 0) {
        		$exp1 = date('d/m/Y',$vipData['certificate_expire_date']);
        		$this->template->assign("certificate_expire_date", $exp1);
        	} else {
        		$this->template->assign("certificate_expire_date", "");
        	}
        	
        	if ($vipData['certificate_expire_date_p12'] > 0) {
        		$exp2 = date('d/m/Y',$vipData['certificate_expire_date_p12']);
        		$this->template->assign("certificate_expire_date_p12", $exp2);
        	} else {
        		$this->template->assign("certificate_expire_date_p12", "");
        	}
        	
        	
			//========= step 2. upload cer
        	
        	$has_cer_pem = "0";
        	if ($vipData['certificate_file_path'] != '') {
        		$has_cer_pem = "1";
        		$this->template->assign("has_cer_pem", $has_cer_pem);
        		$view_cer_pem_path = $this->UploadCerUrl.$params['account']['client_id']."/".$vipData['certificate_file_path'];
        		$view_cer_pem_local_path = $this->UploadCerPath.$params['account']['client_id']."/".$vipData['certificate_file_path'];
        		
        		//========= file name path
        		$this->template->assign("certificate_file_name", $vipData['certificate_file_name']);
        		$this->template->assign("certificate_file_path", $vipData['certificate_file_path']);
        
        		//======== file type 
        		$this->template->assign("certificate_file_type", $vipData["certificate_file_type"]);
        		$this->template->assign("view_cer_pem_path", $view_cer_pem_path);
        		
        		//======== file size 
        		$this->template->assign("file_size", number_format($vipData["certificate_file_size"],0));
        		
        		//======== file upload date 
        		if ($vipData['date_file_upload'] > 0) {
        			$date_upload = date('d/m/Y',$vipData['date_file_upload']);
        			$this->template->assign("date_file_upload_pem", $date_upload);
        		} else {
        			$this->template->assign("date_file_upload_pem", "");
        		}
        		
        		//======== file last upload date 
        		if ($vipData['date_file_last_upload'] > 0) {
        			$last_upload = date('d/m/Y',$vipData['date_file_last_upload']);
        			$this->template->assign("date_file_last_upload_pem", $last_upload);
        		} else {
        			$this->template->assign("date_file_last_upload_pem", "");
        		}
        		
        		$this->template->assign("md5sum", $vipData["md5sum"]);
        		
        	}
        		
	        	
	        $has_cer_p12 = "0";
        	if ($vipData['certificate_file_path_p12'] != '') {
        		$has_cer_p12 = "1";
        		$this->template->assign("has_cer_p12", $has_cer_p12);
        		$view_cer_p12_path = $this->UploadCerUrl.$params['account']['client_id']."/".$vipData['certificate_file_path_p12'];
        		$view_cer_p12_local_path = $this->UploadCerPath.$params['account']['client_id']."/".$vipData['certificate_file_path_p12'];
        		
        		//=============== file p12
	        	$this->template->assign("certificate_file_name_p12", $vipData['certificate_file_name_p12']);
	        	$this->template->assign("certificate_file_path_p12", $vipData['certificate_file_path_p12']);
	        	$this->template->assign("certificate_expire_date_p12", $exp2);  
        				
        		//======== file type 
         		$this->template->assign("certificate_file_type_p12",  $vipData['certificate_file_type_p12']);
        		$this->template->assign("view_cer_p12_path", $view_cer_p12_path);

        		//======== file size 
        		$this->template->assign("file_size_p12", number_format($vipData['certificate_file_size_p12'],0));
        		
        		//======== file upload date 
        		if ($vipData['date_file_upload_p12'] > 0) {
        			$date_upload_p12 = date('d/m/Y',$vipData['date_file_upload_p12']);
        			$this->template->assign("date_file_upload_p12", $date_upload_p12);
        		} else {
        			$this->template->assign("date_file_upload_p12", "");
        		}
        		
        		//======== file last upload date 
        		if ($vipData['date_file_last_upload_p12'] > 0) {
        			$last_upload_p12 = date('d/m/Y',$vipData['date_file_last_upload_p12']);
        			$this->template->assign("date_file_last_upload_p12", $last_upload_p12);
        		} else {
        			$this->template->assign("date_file_last_upload_p12", "");
        		}
        		
        		$this->template->assign("md5sum_p12", $vipData["md5sum_p12"]);
        		
        	}
        	
        	
        	//========== step 3. cer password
        	$this->template->assign("certificate_file_password", $vipData['certificate_file_password']);
        	$this->template->assign("certificate_file_password_p12", $vipData['certificate_file_password_p12']);
        		
        	
        } else {
        	//if ($params['account']['product_name'] == '2-factor Authentication (Free)') {
        		$this->template->assign("quantity", $vipQty);
        	//}
        }
        
        $pathFolderDoc = $this->UploadCerPath.$params['account']['client_id'];
        
	 	if (is_dir($pathFolderDoc) === false) {
			if (mkDir($pathFolderDoc,0777)) {
				//echo "make dir";
				$doc = $pathFolderDoc;
			}
		}
		
		$this->template->assign("upload_dir", $doc);
        
        $this->template->assign("usr_id", $params['account']['client_id']);
        $this->template->assign("vip_info_type", $params['account']['billingcycle']);
        $this->template->assign("product_id", $params['account']['product_id']);
        $this->template->assign("product_name", $params['account']['product_name']);
       
    }
    
    /**
     * 
     * Enter description here ...
     */
    public function getModuleName() {
        return "symantecvip";
    }
    
     /*****************************************************************
     * step 1 save ou number
     *****************************************************************/  
	public function _validate_doSaveAccount($params) {
        
        $input = array( 
     		"isValid" => true,
          	"resError" => ""
        );
        
        // Variable Defined.
        $input["vipNum"] = (isset($params["vipNum"]) && $params["vipNum"] != "") ? $params["vipNum"] : null;
        $input["vipQuantityAtSymantec"] = (isset($params["vipQuantityAtSymantec"]) && $params["vipQuantityAtSymantec"] != "") ? $params["vipQuantityAtSymantec"] : null;
        $input["vipQuantityOrder"] = (isset($params["vipQuantityOrder"]) && $params["vipQuantityOrder"] != "") ? $params["vipQuantityOrder"] : null;
        $input["vipInfoId"] = (isset($params["vipInfoId"]) && $params["vipInfoId"] != "") ? $params["vipInfoId"] : null;
        $input["vipInfoType"] = (isset($params["vipInfoType"]) && $params["vipInfoType"] != "") ? $params["vipInfoType"] : null;
        $input["usrId"] = (isset($params["usrId"]) && $params["usrId"] != "") ? $params["usrId"] : null;
        $input["productId"] = (isset($params["productId"]) && $params["productId"] != "") ? $params["productId"] : null;
        $input["productName"] = (isset($params["productName"]) && $params["productName"] != "") ? $params["productName"] : null;
        
        if (!isset($input["vipNum"]) || ($input["vipNum"] == "")) {
            $resError = 'กรุณากรอก Organizational Unit Number';
            $input["isValid"] = false;
            $input["resError"] = $resError;
        } else if (!isset($input["vipQuantityAtSymantec"]) || ($input["vipQuantityAtSymantec"] == "")){
            $resError = 'กรุณากรอก จำนวน Account ที่สั่งซื้อใน Symantec VIP official site'; 
            $input["isValid"] = false;
            $input["resError"] = $resError;
        } else if ($input["vipQuantityAtSymantec"] != $input["vipQuantityOrder"]) {
        	$resError = 'กรุณากรอก จำนวน Account ที่สั่งซื้อใน Symantec VIP official site ให้เท่ากับจำนวน account ในการสั่งซื้อ'; 
        	$input["isValid"] = false;
        	$input["resError"] = $resError;
        }
        return $input;
        
    }
    
    public function doSaveAccount($params) {
    	
    	$complete = "1";
        $message = "";
    
        try {
            
            // Validate
            $valid = symantecvip_controller::_validate_doSaveAccount($params);
            if ($valid["isValid"] == false) {
                //throw new Exception($params["resError"]);
                $message = $valid["resError"];
            } else {
            	
            	//if($params['productName'] == '2-factor Authentication (Free)') {
            		//	$billing_cycle_unit = 'M';
            		//	$qty = 1;
            	//}
            	
            	$vip_user_prefix = "vip".$params['usrId']."_";
            	
            	if ($params['vipInfoId'] != '') {
            		$aData = array (
            							'usr_id' =>  $params['usrId'] ,
            							'vip_info_type' => $params['vipInfoType'] ,
            							'ou_number' => $params['vipNum'] ,
            							'quantity_at_symantec' => $params['vipQuantityAtSymantec'],
            							'product_id' => $params['productId'],
            							'billing_cycle_unit' => $billing_cycle_unit,
            							'quantity' => $params["vipQuantityOrder"]
            						);
            		$updateVip = SymantecvipDao::singleton()->updateVIP($aData , $params['vipInfoId']);
            		$resUpdate = $updateVip;
            	} else {
            		
            		$aData = array (
            							'usr_id' =>  $params['usrId'] ,
            							'vip_user_prefix' => $vip_user_prefix ,
            							'vip_info_type' => $params['vipInfoType'] ,
            							'ou_number' => $params['vipNum'] ,
            							'quantity_at_symantec' => $params['vipQuantityAtSymantec'],
            							'product_id' => $params['productId'],
            							'billing_cycle_unit' => $billing_cycle_unit,
            							'quantity' => $params["vipQuantityOrder"],
            						    'can_manage_status' => 'P' ,
            							'status' => 'P'
            						);
            						/*
            						 * 	'billing_cycle_unit' => $billing_cycle_unit,
            							'quantity' => $qty ,
            						 */
            		
            		$addVip = SymantecvipDao::singleton()->addVIP($aData);
            		$resAdd = $addVip;
            	}
            	
	            if ($resAdd === true) {
		        	$message = "บันทึกข้อมูล Step 1: Register VIP Account สำเร็จ";
		        } 
		        
		        if ($resUpdate === true) {
		        	$message = "อัพเดทข้อมูล Step 1: Register VIP Account สำเร็จ";
		        }
           	}
        } catch (Exception $e) {
            $complete = "0";
            $message = $e->getMessage();
        }
        
       
        
        $aResponse = array(
          "complete" => $complete,
          "message" => $message
        );
        
        $this->loader->component('template/apiresponse', 'json');
        $this->json->assign("aResponse", $aResponse);
        $this->json->show();
    }
    
    /*****************************************************************
    * step 2 save certificate file
    *****************************************************************/
	public function _validate_doSaveCertificateFile($params) {
		
		$this->UploadCerPath = MAINDIR . "upload/certificate_file/";
    	$this->UploadCerUrl = system_url . "upload/certificate_file/";

        $input = array( 
     		"isValid" => true,
          	"resError" => ""
        );
     
        // Variable Defined.
        $input["usrIdFolder"] = (isset($params["usrIdFolder"]) && $params["usrIdFolder"] != "") ? $params["usrIdFolder"] : null;
        
        $input["usrId"] = (isset($params["usrId"]) && $params["usrId"] != "") ? $params["usrId"] : null;
        $input["vipInfoId"] = (isset($params["vipInfoId"]) && $params["vipInfoId"] != "") ? $params["vipInfoId"] : null;
        
        $input["vipCerFileName"] = (isset($params["vipCerFileName"]) && $params["vipCerFileName"] != "") ? $params["vipCerFileName"] : null;
        $input["vipCerFileType"] = (isset($params["vipCerFileType"]) && $params["vipCerFileType"] != "") ? $params["vipCerFileType"] : null;
        $input["vipCerFileSize"] = (isset($params["vipCerFileSize"]) && $params["vipCerFileSize"] != "") ? $params["vipCerFileSize"] : null;
        $input["vipCerFilePath"] = (isset($params["vipCerFilePath"]) && $params["vipCerFilePath"] != "") ? $params["vipCerFilePath"] : null;
		$input["vipCerExpireDate"] = (isset($params["vipCerExpireDate"]) && $params["vipCerExpireDate"] != "") ? $params["vipCerExpireDate"] : null;
        
        $input["vipCerFileNameP12"] = (isset($params["vipCerFileNameP12"]) && $params["vipCerFileNameP12"] != "") ? $params["vipCerFileNameP12"] : null;
        $input["vipCerFileTypeP12"] = (isset($params["vipCerFileTypeP12"]) && $params["vipCerFileTypeP12"] != "") ? $params["vipCerFileTypeP12"] : null;
        $input["vipCerFileSizeP12"] = (isset($params["vipCerFileSizeP12"]) && $params["vipCerFileSizeP12"] != "") ? $params["vipCerFileSizeP12"] : null;
        $input["vipCerFilePathP12"] = (isset($params["vipCerFilePathP12"]) && $params["vipCerFilePathP12"] != "") ? $params["vipCerFilePathP12"] : null;
		$input["vipCerExpireDateP12"] = (isset($params["vipCerExpireDateP12"]) && $params["vipCerExpireDateP12"] != "") ? $params["vipCerExpireDateP12"] : null;
		
		$input["dateFileUpload"] = (isset($params["dateFileUpload"]) && $params["dateFileUpload"] != "") ? $params["dateFileUpload"] : null;
		$input["dateFileUploadP12"] = (isset($params["dateFileUploadP12"]) && $params["dateFileUploadP12"] != "") ? $params["dateFileUploadP12"] : null;
            
		//echo "upload_path=".$this->UploadCerPath.$input["usrIdFolder"]."/".$_FILES["vipCerFileNameArray"]["name"];
		
		if (($_FILES["vipCerFileNameArray"]["size"]) > 0 && ($_FILES["vipCerFileNameArray"]["error"]==0)) {
        	if (move_uploaded_file($_FILES["vipCerFileNameArray"]["tmp_name"] , $this->UploadCerPath.$input["usrIdFolder"]."/".$_FILES["vipCerFileNameArray"]["name"])) {
        	}
        }
        
	
		if (($_FILES["vipCerFileNameArrayP12"]["size"]) > 0 && ($_FILES["vipCerFileNameArrayP12"]["error"]==0)) {
        	if (move_uploaded_file($_FILES["vipCerFileNameArrayP12"]["tmp_name"] , $this->UploadCerPath.$input["usrIdFolder"]."/".$_FILES["vipCerFileNameArrayP12"]["name"])) {
        	}
        }
 
        return $input;
        
    }
    
    public function doSaveCertificateFile($params) {
    	
    	$complete = "1";
        $message = "";
    
        try {
            
            // Validate
            $valid = symantecvip_controller::_validate_doSaveCertificateFile($params);
            if ($valid["isValid"] == false) {
                //throw new Exception($valid["resError"]);
                $message = $valid["resError"];
            } else {
  
            	if ($params['vipInfoId'] != '') {
            		
            		$date1 = explode("/" ,$params["vipCerExpireDate"]);
            		$exp1 = mktime(0,0,0,$date1[1],$date1[0],$date1[2]); 
            		
            		$date2 = explode("/" ,$params["vipCerExpireDateP12"]);
            		$exp2 = mktime(0,0,0,$date2[1],$date2[0],$date2[2]); 
            		
            		if ($params['dateFileUpload'] <= 0) {
            			$date_upload = time();
            		} else {
            			$date_upload = "";
            		}
            		
            		if ($params['dateFileUploadP12'] <= 0) {
            			$date_upload_p12 = time();
            		} else {
            			$date_upload_p12 = "";
            		}
            		
            		
            		if ($params['vipCerFilePath'] != '') {
            			$md5sum = md5_file($this->UploadCerPath.$valid["usrIdFolder"]."/".$valid['vipCerFilePath']);
            			$file_data = file_get_contents($this->UploadCerPath.$valid["usrIdFolder"]."/".$valid['vipCerFilePath']);
               			
               			/*
            			$filename = $this->UploadCerPath.$input["usrIdFolder"]."/".$params['vipCerFilePath'];
            			$data = "";
						if (is_file($filename) === true) {
							$data = file($filename);
							$data = join('', $data);
						}
						
						$file_data = $data;
						*/

            		}
            		
            		if ($params['vipCerFilePathP12'] != '') {
            			$md5sump12 = md5_file($this->UploadCerPath.$valid["usrIdFolder"]."/".$valid['vipCerFilePathP12']);
            			$file_data_p12 = file_get_contents($this->UploadCerPath.$valid["usrIdFolder"]."/".$valid['vipCerFilePathP12']);
            		
						/*
            			$data_p12 = "";
						if (is_file($filename_p12) === true) {
							$data_p12 = file($filename_p12);
							$data_p12 = join('', $data_p12);
						}
						
						$file_data_p12 = $data_p12;
						*/
						
						$file_data_p12_encode = base64_encode($file_data_p12);
            		}

            		
            	 	/*
			            [name] => vip_cert.pem
			            [type] => application/x-x509-ca-cert
			            [tmp_name] => /tmp/phpO54tbY
			            [error] => 0
			            [size] => 4765
			         */

            		$aData = array (
            							'certificate_file_name' =>  $params['vipCerFileName'] ,
            							'certificate_file_type' =>  $params['vipCerFileType'] ,
            							'certificate_file_size' =>  $params['vipCerFileSize'] ,
            							'certificate_file_path' =>  $params['vipCerFilePath'] ,
            							'certificate_file_content' => $file_data,
            							'certificate_expire_date' => $exp1 ,
            							'date_file_upload' => $date_upload,
            							'date_file_last_upload' => time(),
            							'md5sum' => $md5sum,
            							'symantec_connection' => $params['symantec_connection'],
            							'certificate_file_name_p12' =>  $params['vipCerFileNameP12'] ,
            							'certificate_file_type_p12' =>  $params['vipCerFileTypeP12'] ,
            							'certificate_file_size_p12' =>  $params['vipCerFileSizeP12'] ,
            							'certificate_file_path_p12' =>  $params['vipCerFilePathP12'] ,
            							'certificate_file_content_p12' => $file_data_p12_encode ,
            							'certificate_expire_date_p12' => $exp2 ,
            							'date_file_upload_p12' => $date_upload_p12 ,
            							'date_file_last_upload_p12' => time() ,
            							'md5sum_p12' => $md5sump12
            						);
            						
            		$updateVipCer = SymantecvipDao::singleton()->updateVIPCertificateFile($aData , $params['vipInfoId']);
            		$resUpdate = $updateVipCer;
            	}
		        
		        if ($resUpdate === true) {
		        	$message = "อัพเดทข้อมูล Step 2: Upload Certificate File สำเร็จ กรุณาตรวจสอบข้อมูลใน Step 3 ใหม่ ";
		        }
		        else {
		        	$message = "อัพเดทข้อมูล Step 2: Upload Certificate File ไม่สำเร็จ กรุณาลองใหม่อีกครั้ง";
		        }
           	}
        } catch (Exception $e) {
            $complete = "0";
            $message = $e->getMessage();
        }
           
        $aResponse = array(
          "complete" => $complete,
          "message" => $message
        );
        
        
        $this->loader->component('template/apiresponse', 'json');
        $this->json->assign("aResponse", $aResponse);
        $this->json->show();
    }
    
    
    /*****************************************************************
     * step 3 save password
     *****************************************************************/  
	public function _validate_doSaveCertificateFilePassword($params) {
        
        $input = array( 
     		"isValid" => true,
          	"resError" => ""
        );
        
        // Variable Defined.
        $input["vipCerFilePassword"] = (isset($params["vipCerFilePassword"]) && $params["vipCerFilePassword"] != "") ? $params["vipCerFilePassword"] : null;
        $input["vipCerFilePasswordP12"] = (isset($params["vipCerFilePasswordP12"]) && $params["vipCerFilePasswordP12"] != "") ? $params["vipCerFilePasswordP12"] : null;
        
        $input["vipInfoId"] = (isset($params["vipInfoId"]) && $params["vipInfoId"] != "") ? $params["vipInfoId"] : null;
        
        if (isset($input["vipCerFilePassword"]) && ($input["vipCerFilePassword"] != "")
         && isset($input["vipCerFilePasswordP12"]) && ($input["vipCerFilePasswordP12"] != "")) {
         	
        } else {
        	$resError = "";
        	
        	if (!isset($input["vipCerFilePassword"]) || ($input["vipCerFilePassword"] == "")) {
            	$resError = 'กรุณากรอก Certificate File Password ของไฟล์ .pem';
        	} else if (!isset($input["vipCerFilePasswordP12"]) || ($input["vipCerFilePasswordP12"] == "")){
            	$resError = 'กรุณากรอก Certificate File Password ของไฟล์ .p12'; 
        	}
        	
        	$input["isValid"] = false;
        	$input["resError"] = $resError;
        }

        return $input;
    
    }
    
    public function doSaveCertificateFilePassword($params) {
    	
    	$complete = "1";
        $message = "";
    
        try {
            
            // Validate
            $input = symantecvip_controller::_validate_doSaveCertificateFilePassword($params);
            if ($input["isValid"] == false) {
                throw new Exception($input["resError"]);
            } else {
  
            	if ($params['vipInfoId'] != '') {

            		$aData = array (
            							'certificate_file_password' =>  $params['vipCerFilePassword'] ,
            							'certificate_file_password_p12' => $params['vipCerFilePasswordP12'] ,
            						);
            						
            		$updateVipCerPass = SymantecvipDao::singleton()->updateVIPCertificateFilePassword($aData , $params['vipInfoId']);
            		$resUpdate = $updateVipCerPass;
            	}
		        
		        if ($resUpdate === true) {
		        	$message = "อัพเดทข้อมูล Step 3: Certificate Password สำเร็จ";
		        }
		        else {
		        	$message = "อัพเดทข้อมูล Step 3: Certificate Password ไม่สำเร็จ กรุณาลองใหม่อีกครั้ง";
		        }
           	}
        } catch (Exception $e) {
            $complete = "0";
            $message = $e->getMessage();
        }
        
        $aResponse = array(
          "complete" => $complete,
          "message" => $message
        );
        
        
        $this->loader->component('template/apiresponse', 'json');
        $this->json->assign("aResponse", $aResponse);
        $this->json->show();
    }
    
    
	
    
    
    
    
}







