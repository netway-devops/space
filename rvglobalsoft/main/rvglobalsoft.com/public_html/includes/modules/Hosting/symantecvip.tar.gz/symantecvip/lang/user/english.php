<?php

/**
 * Hosting Module Class - Symantec VIP
 * 
 * http://dev.hostbillapp.com/additional-resources/using-languagestranslations-in-your-modulescustom-code/
 * http://wiki.hostbillapp.com/index.php?title=Add_new_languages
 * 
 */

// NETWORK TRAFFIC
$lang['global']['Rv_Vip_Order_Desc'] = 'Symantec VIP (Free 1 account for 30 days)';