<?php 
#@LICENSE@#
?>
<?php
// add menu on client left menu
/**
 * This event is called when clientarea header is rendered -
 * use this to inject your custom scripts/meta tags etc.
 */

define("VIP_MOD_DIR","Rvtwofactor");
define('RVGLOBALSTORE_API_URL', 'http://api.rvglobalsoft.com/apps');
define('RV_APPS_ID', 'hostbill');
set_include_path(HBFDIR_LIBS . 'pear' . PATH_SEPARATOR . APPDIR_MODULES . 'Other/' . VIP_MOD_DIR . '/Lib-oAuthConnect/PHP/pear' . PATH_SEPARATOR . dirname(__FILE__) . '/' . VIP_MOD_DIR . '/Lib-oAuthConnect/PHP/RvLibs' . PATH_SEPARATOR . get_include_path());
if (!class_exists('PEAR',false)) {
	require_once 'PEAR.php';
}
require_once APPDIR_MODULES . 'Other/' . VIP_MOD_DIR . '/Lib-oAuthConnect/PHP/RvLibs/RvGlobalStoreApi.php';
$db = hbm_db();

function add_hb_vip_user_client_detail($user_login)
{
	$db = hbm_db();
	$sql_IN = "INSERT INTO vip_user_detail
						 ( user_login 
						 , enable_status 
						 , user_type)
				  VALUES ('" . $user_login . "'
						 , 0 
						 , 'CLIENT' ) ";
	if ($db->query($sql_IN)) {
		return 1;
	} else {
		return 0;
	}
}

function client_get_vip_setting()
{
	$db = hbm_db();
	$sql = "select * from vip_setting where setting_id = '1' ";
	$result = $db->query($sql)->fetch();
	return $result;
}

function connect_rv_api_client($app_user_id, $app_access_key)
{
	$oAuth =& RvLibs_RvGlobalStoreApi::singleton();
	$oUserConnect = RvLibs_RvGlobalStoreApi::connect(RVGLOBALSTORE_API_URL, $app_user_id, $app_access_key);
	return $oUserConnect;
}

function get_ip() 
{
    if ( isset( $_SERVER["HTTP_CF_CONNECTING_IP"] ) ) {
      return $_SERVER['HTTP_CF_CONNECTING_IP'];
    }
    if ( isset( $_SERVER["HTTP_X_FORWARDED_FOR"] ) ) {
      return $_SERVER['HTTP_X_FORWARDED_FOR'];
    }
    if ( isset( $_SERVER["REMOTE_ADDR"] ) ) {
      return $_SERVER['REMOTE_ADDR'];
    }
}

function get_ip_xxx($ip) 
{
	$ip_array = explode( "." , $ip);
	$three_ip = $ip_array[0].".".$ip_array[1].".".$ip_array[2];
	return $three_ip;
}

function get_style_css_client() 
{
	
	$css = "
				<style type='text/css'>
					body {
					    background: none repeat scroll 0 0 #FFFFFF;
					    font-size: 12px;
					    margin: 0 auto;
					    padding: 0;
					}
					.block-input {
					    border: 1px solid #000000;
					    float: left;
					    font-family: Verdana,Geneva,sans-serif;
					    line-height: 20px;
					    margin: 100px auto 0;
					    min-width: 480px;
					    width: auto;
					}
					.titlebar {
					    background-color: #FFC20F;
					    color: #000000;
					    font-size: 14px;
					    padding: 10px;
					    text-align:center;
					}
					.add-symantect {
					    color: #333333;
					    font-family: Arial,Helvetica,sans-serif;
					    font-size: 14px;
					    line-height: 25px;
					    padding: 10px;
					}
					.add-symantect .btn, .add-symantect .btn:visited, .add-symantect .btn:hover, .add-symantect .btn:active {
					    background: none repeat scroll 0 0 #4F4F4F;
					    border: 0 none;
					    border-radius: 3px;
					    color: #FFFFFF;
					    cursor: pointer;
					    display: inline;
					    margin-right: 3px;
					    padding: 5px 15px;
					    text-decoration: none;
					    white-space: nowrap;
					    width: 90px;
					}
					.add-symantect .btn:hover, .add-symantect .btn:active {
					    background: none repeat scroll 0 0 #636363;
					    color: #FFFFFF;
					}
					.add-symantect a, .add-symantect a:visited, .add-symantect a:hover, .add-symantect a:active {
					    color: #C74B00;
					    font-size: 12px;
					    text-decoration: underline;
					}
					.add-symantect a:hover, .add-symantect a:active {
					    color: #000000;
					}
					.add-symantect .box {
					    background: none repeat scroll 0 0 #FFFFFF;
					    border: 1px solid #757575;
					    padding: 4px;
					    width: 200px;
					}
					.add-symantect h2 {
					    font-family: Arial,Helvetica,sans-serif;
					    font-size: 16px;
					}
					.add-symantect .clear {
					    clear: both;
					    margin: 0;
					    padding: 0;
					}
					.add-symantect .name {
					    color: #0066CC;
					}
					a.new_control.greenbtn, a.menuitm.greenbtn, .greenbtn {
					    background: none repeat scroll 0 0 #56A805;
					    border-color: #36A547;
					    color: #FFFFFF;
					    font-size: 12px;
					    font-weight: normal;
					    margin: 5px 0;
					    padding: 3px 8px;
					    text-shadow: 0 1px 0 #808080;
					}
					a.new_control.greenbtn:hover, a.menuitm.greenbtn:hover, .greenbtn:hover {
					    background: none repeat scroll 0 0 #89C24F;
					    border-color: #31853D;
					    color: #FFFFFF;
					    font-weight: normal;
					}
					</style>";
	return $css;
}

function insert_vip_user_access_client($cookie_val, $client_ip, $user_name_login, $user_agent, $cookie_age) 
{
	$db = hbm_db();
	$sql_c = "INSERT INTO vip_user_access ( session_id
											, client_ip
											, user_login
											, http_user_agent
											, cookie_expire
										 ) 
								VALUES ( '".$cookie_val."'
										, '".$client_ip."'
										, '".$user_name_login."'
										, '".$user_agent."'
										, '".$cookie_age."'
									   ) ";
	if($db->query($sql_c)) {
		return true;
	} else {
		return false;
	}
}


function display_login_result_client($login_status_text, $login_credential_id) 
{
	$valid_login = "<style>
					.valid_box {
						border:1px solid #009900; 
						background-color: #99FF99; 
						width:480px; 
						text-align:center; 
						padding:10px;
						color='#009900;
					}
					</style>";
	$valid_login .= "<br /><center><div class='valid_box'>" . $login_status_text;
	$valid_login .= " Credential ID is " . $login_credential_id . "</div></center>";
	return $valid_login;
}

function display_login_result_error_client($login_status_text) 
{
	$err_login = "<style>
					.valid_box {
						border:1px solid #FF0000; 
						background-color: #FFCCCC; 
						width:480px; 
						text-align:center; 
						padding:10px;
						color='#009900;
					}
					</style>";
	$err_login .= "<br /><center><div class='valid_box'>" . $login_status_text;
	$err_login .= "</div></center><br />";
	return $err_login;
}

function makeVipAppsAccesslogsClient($a_DataLog) 
{

	$aDataLog = array();
	$aDataLog = $a_DataLog;

	$cpPath = explode("/" , $_SERVER['DOCUMENT_ROOT']);
	$cpPathLog = "/".$cpPath[1]."/".$cpPath[2];

	$path1 = $cpPathLog."/.rvglobalsoft/symantecvip";
	if(!is_dir($path1)) {
		mkdir($path1,0777);
	}

	$path2 = $cpPathLog."/.rvglobalsoft/symantecvip/logs";
	if(!is_dir($path2)) {
		mkdir($path2,0777);
	}

	$pathFile3 = $cpPathLog."/.rvglobalsoft/symantecvip/logs/vipAppsAccesslogs.log";

	$objFopen3 = fopen($pathFile3, 'a');
	$strText3 = $aDataLog['log_time'] . "," . $aDataLog['status'] . "," . $aDataLog['statusMessage'];
	$strText3 .= "," . $aDataLog['detail'] . "," . $aDataLog['detailMessage'] . "," . $aDataLog['vip_acct_name'];
	$strText3 .= "," . $aDataLog['vip_cred'] . "," . $aDataLog['appsuser_id'] . "," . $aDataLog['remote_user'];
	$strText3 .= "," . $aDataLog['access_ip'] . "," . $aDataLog['user_type'] . "\r\n";
	fwrite($objFopen3, $strText3);

	if($objFopen3)
	{
		//echo "File writed.";
	}
	else
	{
		//echo "File can not write";
	}
	fclose($objFopen3);
}

function makeVipAppsAccesslogsAppsClient($a_DataLog, $appsuser_id) 
{

	$aDataLog = array();
	$aDataLog = $a_DataLog;
	$cpPath = explode("/" , $_SERVER['DOCUMENT_ROOT']);
	$cpPathLog = "/".$cpPath[1]."/".$cpPath[2];
	$path3 = $cpPathLog."/.rvglobalsoft/symantecvip/logs/vipAppsAccesslogs";
	if(!is_dir($path3)) {
		mkdir($path3,0777);
	}
	$strFileName = $path3."/".$appsuser_id.".log";

	$objFopen = fopen($strFileName, 'a');
	$strText1 = $aDataLog['log_time'] . "," . $aDataLog['status'] . "," . $aDataLog['statusMessage'];
	$strText1 .= "," . $aDataLog['detail'] . "," . $aDataLog['detailMessage'] . "," . $aDataLog['vip_acct_name'];
	$strText1 .= "," . $aDataLog['vip_cred'] . "," . $aDataLog['appsuser_id'] . "," . $aDataLog['remote_user'];
	$strText1 .= "," . $aDataLog['access_ip'] . "," . $aDataLog['user_type'] . "\r\n";
	fwrite($objFopen, $strText1);

	if($objFopen)
	{
		//echo "File writed.";
	}
	else
	{
		//echo "File can not write";
	}
	fclose($objFopen);
}


function validateCredAppClient($aPOST) 
{

	$appsuser_id = $aPOST['userId'];
	$vip_acct_id = $aPOST['vip_acct_id'];
	$otp = $aPOST['otp'];
	$vip_cred = $aPOST['credentialId'];
	$otp = str_replace("'", "", $aPOST['otp']);
	$otp = str_replace('"', '', $aPOST['otp']);

	$oRes = RvLibs_RvGlobalStoreApi::singleton()->request('post',
					 '/vipuserinfo', array(
											'action_do' => 'validate_cred_app' , 
											'vip_acct_id' => $vip_acct_id , 
											'appsuser_id' => $appsuser_id ,
											'otp' => $otp ,
											'vip_cred' => $vip_cred
	));
	$oResR = (array) $oRes;
	return $oResR;
}


function delete_vip_user_detail_client($user_login, $user_type) 
{
	$db = hbm_db();
	$sqld0 = "DELETE FROM vip_user_detail
							WHERE user_login = '".$user_login."' 
							AND user_type = '".$user_type."'  ";

	if ($db->query($sqld0)) {
		return true;
	} else {
		return false;
	}
}



function getCookieClient($cookieVar)
{
	$db = hbm_db();
	$sql_k = "SELECT
					* 
				FROM 
					vip_user_access 
				WHERE 
					session_id = '" . $cookieVar . "' 
				AND  
					cookie_expire > " . time() . " 
				ORDER BY 
					acc_id DESC 
				LIMIT 0,1 ";
	$cookie_array = $db->query($sql_k)->fetch();
	return $cookie_array;
}


function selectVipUserDetailByUserLoginUserTypeClient($user_login, $UserType)
{
	$db = hbm_db();
	$sql = "SELECT *
			 FROM vip_user_detail 
			 WHERE user_login = '" . $user_login . "'
			 AND user_type = '" . $UserType . "'  ";
	$res = $db->query($sql)->fetch(); 
	return $res;
}

function check_vip_setting() 
{
	$db = hbm_db();
	$sql_check1 = "SELECT COUNT('TABLE_NAME') AS cnt
				FROM `information_schema`.`TABLES`
				WHERE TABLE_NAME = 'vip_setting' ";
	$res_check1 = $db->query($sql_check1)->fetch();
	return $res_check1['cnt'];
}

function check_vip_user_detail() 
{
	$db = hbm_db();
	$sql_check2 = "SELECT COUNT('TABLE_NAME') AS cnt
				FROM `information_schema`.`TABLES`
				WHERE TABLE_NAME = 'vip_user_detail' ";
	$res_check2 = $db->query($sql_check2)->fetch();
	return $res_check2['cnt'];
}

function check_vip_user_access() 
{
	$db = hbm_db();
	$sql_check3 = "SELECT COUNT('TABLE_NAME') AS cnt
				FROM `information_schema`.`TABLES`
				WHERE TABLE_NAME = 'vip_user_detail' ";
	$res_check3 = $db->query($sql_check3)->fetch();
	return $res_check3['cnt'];
}

function check_modules_active($db_prefix)
{
	$db = hbm_db();
	$sql_check = "	SELECT * 
					FROM ".$db_prefix."modules_configuration 
					WHERE module = 'rvtwofactor' ";
	$res_check = $db->query($sql_check)->fetch();
	return $res_check;
}


$res_check1 = check_vip_setting();
$res_check2 = check_vip_user_detail();
$res_check3 = check_vip_user_access();
$db_prefix = HBF_DBPREFIX;
$res_check = check_modules_active($db_prefix); 

if (  ($res_check['active'] == 1) 
			&& ($res_check1 == 1) 
			&& ($res_check2 == 1) 
			&& ($res_check3 == 1) ) {

	$result = client_get_vip_setting();
	$oUserConnect = connect_rv_api_client($result['app_user_id'], $result['app_access_key']);

	if ($_SERVER['SERVER_NAME'] == 'netway.co.th')
	{
		$rv2factor_label = "Netway2Factor";
		$rv2factor_invite_label = "ปกป้องโดเมนและข้อมูลของคุณด้วยระบบล็อกอินแบบยืนยันตัวตน ปลอดภัยจากแฮกเกอร์ทุกรูปแบบ";
		$rv2factor_invite_label2 = "สนใจใช้งานคลิกที่นี่";
	} else {
		$rv2factor_label = "RV2Factor";
		$rv2factor_invite_label = "You can get more security in your account. By enabling ".$rv2factor_label;
		$rv2factor_invite_label2 = "Click here.";
	}

	$_SESSION['RV_DISMISS'] = $_GET['rv_dismiss'];

	//echo $_SESSION['RV_DISMISS'];

	$user_login = $_SESSION['AppSettings']['login']['id'];
	$admin_login = $_SESSION['AppSettings']['admin_login']['id'];
	//echo $_SESSION['AppSettings']['login']['email'];
	//echo "id=".$_SESSION['AppSettings']['login']['id'];
	$db = hbm_db();

	if($_POST['validate_button'] != '') {

		$result = client_get_vip_setting();
		$userId = $result['vip_user_prefix'].$result['app_user_id']."_".$user_login;
		$appsuser_id = $result['app_user_id'];
		$config_rem_day = $result['remember_device_day'];

		$PRO_FILE_PATH = APPDIR_MODULES . "Other/Rvtwofactor";

		$path_cer_file = $PRO_FILE_PATH."/temp/vip_cert.pem";
		$path_cer_pass_file = $PRO_FILE_PATH."/temp/cerPasswd.txt";
		$cer_pass = file_get_contents($path_cer_pass_file);

		$m_url_client = "https://services.vip.symantec.com";
		$m_url_issuer = "https://services-auth.vip.symantec.com";

		$mgmtPrefix = "/mgmt/soap";
		$valPrefix = "/val/soap";

		$wsdl2 = $PRO_FILE_PATH.'/Symantec/vipuserservices-auth-1.1.wsdl';

		try {
			$options2 = array(
                'local_cert' => $path_cer_file,
                'trace'=>true,
                'cache_wsdl'=>WSDL_CACHE_NONE,
    		    'passphrase'=> $cer_pass,
                'location' => 'https://userservices-auth.vip.symantec.com/vipuserservices/AuthenticationService_1_1'	   
                );
                 
                $client2 = new SoapClient($wsdl2, $options2);

		} catch (Exception $e) {

			echo "<h2>Exception Error!</h2>";
			echo $e->getMessage();

		}

		$req_id = time();
		$otp = $_POST['otp'];

		$t2 = array(	'requestId' => $req_id ,
                    'userId' => $userId , 
                    'otpAuthData' => array( 
                                           	'otp' => $otp
		)
		);


		$response2 = $client2->authenticateUser($t2);

		if (($response2->credentialId != '') && ($response2->statusMessage == 'Success') ) {

			$_SESSION['myVIPSession'] = $response2->credentialId;

			$login_status_text = "Login Success";
			$login_credential_id = $response2->credentialId;
			$login_msg = display_login_result_client($login_status_text, $login_credential_id);

			echo $login_msg;
			 
			// start make cookie and save data to db ===========

			if ($_POST['remember'] == 1) {

				// insert into cookie_detail
				$client_ip = get_ip();
				$user_agent = $_SERVER['HTTP_USER_AGENT'];
				$user_name_login = $userId;
				$cookie_age = time() + ($config_rem_day * 86400);
				$cookie_val = session_id();

				if(insert_vip_user_access_client($cookie_val, $client_ip, $user_name_login, $user_agent, $cookie_age)) {
					setcookie('rv2factor_remember_user'.$userId, $cookie_val, $cookie_age , "/" );
				}


			}

			// end make cookie and save data to db =============

			$aDataLog = array (
								'log_time' => time(),
								'status' => $response2->status ,
								'statusMessage' => $response2->statusMessage ,
								'detail' => $response2->status ,
								'detailMessage' => $response2->statusMessage ,
								'vip_acct_name' => $userId ,
								'vip_cred' => $response2->credentialId ,
								'appsuser_id' => $appsuser_id ,
								'remote_user' => $user_login ,
						        'access_ip' => $_SERVER['REMOTE_ADDR'] ,
								'user_type' => 'CLIENT'				
							
								);

		} else {

			$_SESSION['myVIPSession'] = "";

			$login_status_text = $response2->statusMessage;

			$login_msg = display_login_result_error_client($login_status_text);

			echo $login_msg;

			$aDataLog = array (
								'log_time' => time(),
								'status' => $response2->status ,
								'statusMessage' => $response2->statusMessage ,
								'detail' => $response2->detail ,
								'detailMessage' => $response2->detailMessage ,
								'vip_acct_name' => $userId ,
								'vip_cred' => $response2->credentialId ,
								'appsuser_id' => $appsuser_id ,
								'remote_user' => $user_login , 
								'access_ip' => $_SERVER['REMOTE_ADDR'] ,
								'user_type' => 'CLIENT'				
								);


		}

		$make_log1 = makeVipAppsAccesslogsClient($aDataLog);
		$make_log2 = makeVipAppsAccesslogsAppsClient($aDataLog, $appsuser_id);

	} else if ($_POST['save_client_vip_but_add_acct'] != '') {
		$db = hbm_db();
		$ress = client_get_vip_setting();
		$aData = array();
		$appsuser_id = $ress['app_user_id'];

		//======================== process add vip start ====================
		$req_id = time();
		$userId = $appsuser_id . "_" . $user_login;
		$credential_type = "STANDARD_OTP";
		$friendlyName = $_POST['vip_acct_comment'];
		$credentialId = strtoupper($_POST['credentialId']);
		$vip_acct_comment = $user_login;

		// === add vip acct with cred =====//

		$oRes = RvLibs_RvGlobalStoreApi::singleton()->request('post',
						 '/vipuserinfo', array(
												'action_do' => 'addacct_with_cred_app' , 
												'vip_cred' => $credentialId , 
												'vip_cred_comment' => $friendlyName , 
												'vip_acct_name' => $userId ,
												'vip_acct_comment' => $vip_acct_comment ,
												'appsuser_id' => $appsuser_id , 
												'vip_cred_type' => $credential_type
		));
		$oResR = (array) $oRes;

		if( $oResR['status'] == 'success' ) {
			// add user to vip_user_detail
			$vip_acct_id = $oResR['vip_acct_id'];

			if(add_hb_vip_user_client_detail($user_login) == 1) {
					
				$css = get_style_css_client();

				echo $css;

				$validate_form = '
									
					<script type="text/javascript">
								function chk_val_frm(frm) {
									if(frm.otp.value=="") {
										alert("Please insert Security Code");
										frm.otp.focus();
										return false;
									}
									return true;
								}
							</script>
						
							<script type="text/javascript">
								window.onload = function() {
							  		document.getElementById("otp").focus();
								};
							</script> 	
							
							
										
					<center>
							
						<table align="center" border="0" style="min-width:480px">
							<tr>
								<td>
						
							<div class="block-input">
							    <div class="titlebar"><b>Validate Credential ID</b></div>
							    <div class="add-symantect">

								<div>Insert your security code to confirm adding credential.</div>
			
						
							
							<form name="validate_cred" method="post" action="" onsubmit="return chk_val_frm(this)">
							
							<input type="hidden" name="userId" value="'.$appsuser_id.'">
							<input type="hidden" name="vip_acct_id" value="'.$vip_acct_id.'">
							<input type="hidden" name="credentialId" value="'.$credentialId.'">
							
							<table align="center" border="0" style="min-width:480px">
							<tr>
								<td align="left">Credential ID : </td>
							</tr>
							<tr>
								<td align="left"><input type="text" value="'.$credentialId.'" style="width:200px;background-color:#A0FA9B"></td>
							</tr>
							<tr>
								<td align="left">Note : </td>
							</tr>
							<tr>
								<td align="left"><input type="text" value="'.$friendlyName.'" style="width:200px;background-color:#A0FA9B"></td>
							</tr>
							
							<tr>
								<td align="left">Security Code : </td>
							</tr>
							<tr>
								<td align="left"><input type="text" name="otp" id="otp" MAXLENGTH="6" style="width:200px;"></td>
							</tr>
							
							<tr>
								<td align="left"><input type="submit" name="validate_cred_but_client" value="Validate" class="new_control greenbtn"></td>
							</tr>
							
							<tr>
								<td align="center">
								<div style="text-align:center">
									<img src="'.$system_url.'/includes/modules/Other/Rvtwofactor/images/logo.gif" 
										alt="" width="95" height="41" />
								</div>
								<div style="text-align:center"> <a href="?action=logout" title="Logout">Logout</a>
								 | 
								 <a href="https://m.vip.symantec.com/home.v" target="_blank">Get VIP Access</a> 
								</div>
								
								</td>
							</tr>
							</table>
							
							</form>
							
							</div>							
							
							</div>
							
							</td>
							</tr>
							</table>
							
							
							</center>
							
							';
					
				echo $enable_vip_service_client_text;
				echo $validate_form;
				exit;
			} else {
				$msg = $oResR['comment'];
			}
		} else {
			$msg = $oResR['comment'];
		}

	} else if ($_POST['validate_cred_but_client'] != '') {

		$db = hbm_db();
		// validate credential
		$appsuser_id = $_POST['userId'];
		$vip_acct_id = $_POST['vip_acct_id'];
		$otp = $_POST['otp'];
		$vip_cred = $_POST['credentialId'];

		$otp = str_replace("'", "", $_POST['otp']);
		$otp = str_replace('"', '', $_POST['otp']);


		$ress = client_get_vip_setting();
		$aPOST = $_POST;
		$oResR = validateCredAppClient($aPOST);

		// return add account result from symantec
		if ($oResR['status'] == 'success') {

			// save to db
			$msg = '<font color="green">Add and validate Symantec VIP Credential ID : ' . $vip_cred . ' is successful</font><br />';
			//echo $err_comment;
		} else {

			$del_user_id = $_SESSION['AppSettings']['login']['id'];
			$msg = "<font color='#FF0000'>" . $oResR['comment'] . "</font>";
			$user_type1 = "CLIENT";
			$delUser = delete_vip_user_detail_client($user_login, $user_type1);

		}
	}
	// end if post

	$result = client_get_vip_setting();
	$userId = $result['vip_user_prefix'].$result['app_user_id']."_".$user_login;
	$appsuser_id = $result['app_user_id'];


	if ($result['enable_vip_service'] == 0) {
		$enable_vip_service_client_text = "<center><div style='width:100% text-align:center'>" . $rv2factor_label . "
											System is disabled by admin.
										</div></center>";
	} else if ($result['enable_vip_service'] == 1) {
		$enable_vip_service_client_text = "<center><div style='width:100% text-align:center'>" . $rv2factor_label . "
											System is enabled by admin.
										</div></center>";
	} else if ($result['enable_vip_service'] == 2) {
		$enable_vip_service_client_text = "<center><div style='width:100% text-align:center'>" . $rv2factor_label . "
											System is enabled and enforce by admin.
										</div></center>";
	}


	$UserType = 'CLIENT';
	$resultu = selectVipUserDetailByUserLoginUserTypeClient($user_login, $UserType);
	$load_force_add_acct = 0;
	if ($resultu['user_login'] == '') {
		if ($_SESSION['AppSettings']['login']['email'] == 'isara@rvglobalsoft.com') {
			$load_force_add_acct = 1;
		}
	}

	$cnt = 0;

	if ($msg != "") {
		echo "<div align='center' width='100%' style='text-align:center;margin-top:30px;'>".$msg."</div>";
	}

	if ($result['enable_vip_service'] > 0) {

		// ENABLED BY USER || FORCE BY ADMIN
		if( ($resultu['enable_status'] == 1) || ($result['enable_vip_service'] == 2) || ($_SESSION['AppSettings']['login']['email'] == 'isara@rvglobalsoft.com') ) {

			$load_login_page = 1;

			//echo $enable_vip_service_client_text;

			// ======================= check cookie compare cookie in db
			if ( isset($_COOKIE['rv2factor_remember_user'.$userId] )) {

				$cookie_var = $_COOKIE['rv2factor_remember_user'.$userId];
				$cookie_array = getCookieClient($cookie_var);
					
				$res_session_id = $cookie_array['session_id'];
				$res_client_ip = $cookie_array['client_ip'];
				$res_user_login = $cookie_array['user_login'];
				$res_user_agent = $cookie_array['http_user_agent'];

				$now_ip = get_ip();
				$now_ip_xxx = get_ip_xxx($now_ip);

				$res_client_ip_xxx = get_ip_xxx($res_client_ip);

				if ( ($res_client_ip_xxx == $now_ip_xxx ) && ($res_user_login == $userId) && ($res_user_agent == $_SERVER['HTTP_USER_AGENT']) ) {
					$load_login_page = 0;
				} else {
					$load_login_page = 1;
				}
			}

			//================== end compare cookie in db

			if (($_SESSION['myVIPSession'] == "") && ($admin_login == '') && ($user_login != '') && ($load_login_page == 1) ) {

				$cnt = 1;
					
				if ($load_force_add_acct == 0) {

					$css = get_style_css_client();

					echo $css;

					echo $enable_vip_service_client_text;

					// has user vip
					echo "
					
					<script type='text/javascript'>
							function chk_val_frm(frm) {
								if(frm.otp.value=='') {
									alert('Please insert Security Code');
									frm.code.focus();
									return false;
								}
								return true;
							}
					</script>
					 
					
										
				<script type='text/javascript'>
					window.onload = function() {
					document.getElementById('code').focus();
					};
				</script> 
						
						<div align='center'>
					
						<form action='' method='post' onsubmit='return chk_val_frm(this)'>
							
						<table align='center' border='0'>
							<tr>
								<td>
						
							<div class='block-input'>
							    <div class='titlebar'><b>Enter the security code from your credential</b></div>
							    <div class='add-symantect'>
    				
									<div align='left' style='float:left; width:105px;'>
										<label for='code'>Security Code :</label>
									</div>
									
									<div align='left'>
										<input type='text' name='otp' id='code' maxlength='6' class='box'  autocomplete='off' />
									</div>";

					if ($result['remember_device_status'] == 'ENABLED') {
						echo "<div align='left'>
													<table width='100%'> 
														<tr>
															<td>
														<input type='checkbox' name='remember' id='remember' value='1' />
															</td>
															<td>
													 			<label for='remember'>
													 				Remember this device for " . $result['remember_device_day'] . " days
													 			</label>
													 		</td>
													 	</tr>
													 </table>
										 			</div>
										 	  </div>";
					}

					echo "<div align='center'>
											<input type='submit' name='validate_button' value='Login'  class='new_control greenbtn' />
										   </div>
										   
										   <div align='center'><img src='".$system_url."/includes/modules/Other/Rvtwofactor/images/logo.gif' alt=''
										    width='95' height='41' />
										   </div>
					   
					   			<div align='center'>
					   				<a href='?action=logout' title='Logout'>Logout</a> 
					   				| 
					   			    <a href='https://m.vip.symantec.com/home.v' target='_blank'>Get VIP Access</a>
					   		    </div>
					   		    
							</div>
						
						</td>
						</tr>
						</table>
						
						</form>
					</div>
					
					<br />
					<br />
					";
					exit;
				} else if ($load_force_add_acct == 1) {

					$css = get_style_css_client();

					echo $css;

					echo $enable_vip_service_client_text;

					echo "
			     	<script type='text/javascript'>
						function check_frm(frm) {
							if(frm.credentialId.value=='')
							{
								alert('Please insert Credential ID');
								frm.credentialId.focus();
								return false;
							}
							else if (frm.vip_acct_comment.value=='')
							{
								alert('Please insert Note');
								frm.vip_acct_comment.focus();
								return false;
							} 
							return true;
						}
					</script>
		
					<script type='text/javascript'>
						window.onload = function() {
					    document.getElementById('credentialId').focus();
					};
					</script>
					
					<center>
					
						<table align='center' border='0'>
							<tr>
								<td>
						
							<div class='block-input'>
							    <div class='titlebar'><b>Please add your Credential ID</b></div>
							    <div class='add-symantect'>
							    		
					
								<form id='form' name='form' action='' method='post' onsubmit='return check_frm(this)'>
								
								
									<div align='left'>
										Credential ID : 
										<i><font style='font-size:14px;'>
										<a target='_blank' 
										href='http://rvglobalsoft.com/knowledgebase/article/4/where-is-the-credential-id-/'>Where to get Credential ID?</a>
										</font></i>
									</div>
								
									<div align='left'>
										<input type='text' name='credentialId' 
											style='width:200px' id='credentialId' autocomplete='off' /> 
									</div>
								
									<div align='left'>
										Note : 
										<i><font style='font-size:14px;color:#666666'>
										(the device name such as 'John iPhone', etc.)</font></i>
									</div>
									
								
									<div align='left'>
										<input type='text' name='vip_acct_comment' style='width:200px' autocomplete='off' />
									</div>
								
									<div align='left'>
										<input type='submit' name='save_client_vip_but_add_acct' 
											value='Next' class='new_control greenbtn' />
									</div>
								
									<div align='center'>
										<img src='".$system_url."/includes/modules/Other/Rvtwofactor/images/logo.gif'
											 alt='' width='95' height='41' />
									</div>
									<div align='center'>
										<a href='?action=logout' title='Logout'>Logout</a>
										 | 
										<a href='https://m.vip.symantec.com/home.v' target='_blank'>Get VIP Access</a> 
									</div>
							</form>
					</div>
					
					</div>
					
					</td>
					</tr>
					</table>
					
					</center>	
					";
					exit;
				}
			}
		} else {

			if (($user_login != '') && ($_GET['rvaction'] == '') ) {
				echo "<div style='padding-top:10px; padding-bottom:10px;
			background-color:#000000;
			 color:#339900' 
			 width='100%' 
			 align='center'>".$rv2factor_invite_label."  
			 <a href='index.php?cmd=clientarea&rvaction=twofactor'>".$rv2factor_invite_label2."</a>
			 </div>";
					
			}
		}

	} // end if service > 0


}

?>

