<?php 
#@LICENSE@#
?>
<?php
define("VIP_MOD_DIR","Rvtwofactor");
define('RVGLOBALSTORE_API_URL', 'http://api.rvglobalsoft.com/apps');
define('RV_APPS_ID', 'hostbill');
set_include_path(HBFDIR_LIBS. 'pear' . PATH_SEPARATOR . APPDIR_MODULES . 'Other/' . VIP_MOD_DIR . '/Lib-oAuthConnect/PHP/pear' . PATH_SEPARATOR . dirname(__FILE__) . '/' . VIP_MOD_DIR . '/Lib-oAuthConnect/PHP/RvLibs' . PATH_SEPARATOR . get_include_path());
require_once 'PEAR.php';
include_once APPDIR_MODULES . 'Other/' . VIP_MOD_DIR . '/Lib-oAuthConnect/PHP/RvLibs/RvGlobalStoreApi.php';

/**
 * Client  has just been deleted from HostBill database
 * Following variable is available to use in this file:  $details contains informations about deleted client, from API::getClientDetails call
 * Some of keys available (note: if you have custom registration fields they may differ):
 * $details['id']; // new client ID
 * $details['type']; // Personal or Organization account
 * $details['companyname']; // Supplied company name
 * $details['firstname']; //
 * $details['lastname']; //
 * $details['password']; //
 * $details['password2']; //
 * $details['email']; //
 * $details['address1']; //
 * $details['address2']; //
 * $details['city']; //
 * $details['state']; //
 * $details['postcode']; //
 * $details['country']; //
 * $details['phonenumber']; //
 */

Class BeforeClientDelete {

	private $dbh = null;

	public function BeforeClientDelete($dbhb)
	{
		$this->dbh = $dbhb;
	}

	public function get_vip_setting()
	{
		$sql = "SELECT *
				FROM vip_setting 
				WHERE 
					setting_id = '1' ";
		$result = $this->dbh->query($sql)->fetch();
		return $result;
	}

	public function connect_rv_api_client($app_user_id, $app_access_key)
	{
		$oAuth =& RvLibs_RvGlobalStoreApi::singleton();
		$oUserConnect = RvLibs_RvGlobalStoreApi::connect(RVGLOBALSTORE_API_URL, $app_user_id, $app_access_key);
		return $oUserConnect;
	}

	public function delete_vip_user_detail($user_login, $user_type)
	{
		$sql = sprintf("DELETE
						FROM %s
						WHERE
							user_login = %s 
							AND user_type = %s
						"
						, 'vip_user_detail'
						, $this->quote_smart($user_login)
						, $this->quote_smart($user_type)
					   );
		if ($this->dbh->query($sql)) {
			return true;
		} else {
			return false;
		}
	}
	
	public function quote_smart($value)
    {
        // Stripslashes
        if (get_magic_quotes_gpc()) {
            $value = stripslashes($value);
        }
        // Quote if not integer
        if (!is_numeric($value)) {
            $value = "'" .  $value . "'";
        }
        return $value;
    }
    
	public function check_modules_active($db_prefix)
	{
		$sql_check = "	SELECT * 
						FROM ".$db_prefix."modules_configuration 
						WHERE module = 'rvtwofactor' ";
		$res_check = $this->dbh->query($sql_check)->fetch();
		return $res_check;
	}
	
}

$db = hbm_db();
$aDel = new BeforeClientDelete($db);

$db_prefix = HBF_DBPREFIX;
$res_check = $aDel->check_modules_active($db_prefix); 

//$sql_check = "SELECT * FROM ".HBF_DBPREFIX."modules_configuration WHERE module = 'rvtwofactor' ";
//$res_check = $db->query($sql_check)->fetch();
if ($res_check['active'] == 1) {

	//$db = hbm_db();
	


	if($details['id'] != '') {


		$res_s = $aDel->get_vip_setting();
		$vip_acct_name = $res_s['vip_user_prefix'].$res_s['app_user_id']."_".$details['id'];
		$appsuser_id = $res_s['app_user_id'];
		$user_login = $details['id'];
		$user_type = 'CLIENT';

		if($vip_acct_name != '') {

			$oUserConnect = $aDel->connect_rv_api_client($res_s['app_user_id'], $res_s['app_access_key']);

			// ============== delete on symantec vip ============================
			$oRes = RvLibs_RvGlobalStoreApi::singleton()->request('get',
							 '/vipuserinfo', array(
													'action_do' => 'deleteacct_app' , 
													'vip_acct_name' => $vip_acct_name , 
													'appsuser_id' => $appsuser_id 
			));
			$oResR = (array) $oRes;

			if ($oResR['del_status'] == 'success') {
				$comment = "<br /><font color='#0B9E1F'>Delete VIP Account ".$vip_acct_name."
			 ".$oResR['del_status']."</font><br />";
				$user_type1 = "CLIENT";
				$delUser = $aDel->delete_vip_user_detail($user_login, $user_type1);
			} else {
				$comment = "<br /><font color='#FF0000'>Delete Account ".$vip_acct_name." ".$oResR['del_status']."</font><br />";
			}
			// ================== end delete on symantec vip ========================
		}

		$aData = array();
		$aData['del_status'] = $oResR['del_status'];
		$aData['comment'] = $comment;
	}

}

?>



