<?php 
#@LICENSE@#
if (!class_exists('HTTP_OAuth_Consumer',false)) {
	require_once 'HTTP/OAuth/Consumer.php';
}
class RVLibs_oAuth_ConsumerPlugin extends HTTP_OAuth_Consumer
{
    
    public function accept($object)
    {
        $class = get_class($object);
        switch ($class)
        {
        case 'RVLibs_oAuth_Consumer_RequestPlugin':
            $this->consumerRequest = $object;
            break;
        default:
            parent::accept($object);
        }
    }
}