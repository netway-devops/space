<?php 
#@LICENSE@#
?>
<?php 
$action_do = $_GET['action_do'];
if($action_do == 'add-cred-app') {
	$save_but = "<input type='submit' name='save_cred_more' value='Next' class='btn' />";
} else {
	$save_but = "<input type='submit' name='save_admin_vip_but' value='Next' class='btn' />";
}

if ($_SERVER['SERVER_NAME'] == 'netway.co.th')
{
	$rv2factor_label = "Netway2Factor";
} else {
	$rv2factor_label = "RV2Factor";
}


echo "<h4>".$rv2factor_label." > Add Credential</span></h4>"; ?>

<center>
			
<style type='text/css'>				
.add-symantect{
	border:#000000 solid 1px; 
	padding:2px;
	font-family:Arial, Helvetica, sans-serif; 
	color:#333333;
	font-size:14px;
	margin-top:20px;   
}
.add-symantect .block-l{
	float:left; 
	width:250px; 
	height:220px;
	height:260px\9; 
	background:#fff; 
	text-align:center; 
	padding-top:30px;
}
.add-symantect .block-r{
	float:left;  
	background:#fff; 
	text-align:center; 
	padding:20px;
	padding-top:30px;
	padding-top:20px\9;
}
.add-symantect .block-r div{
	padding-bottom:5px;
}
.add-symantect .block-r div.pad{
	padding-top:10px;
}
.add-symantect .btn, .add-symantect .btn:visited, .add-symantect .btn:hover, .add-symantect .btn:active{ 
	color:#fff; 
	text-decoration:none;
	background:#4f4f4f; 
	display:inline; 
	border:0;
	border-radius:3px; 
	padding:5px 15px; 
	margin-right:3px; 
	width:90px; 
	white-space:nowrap; 
	cursor:pointer;
}
.add-symantect .btn:hover, .add-symantect .btn:active{ 
	color:#fff; 
	background:#636363; 
}
.add-symantect a, .add-symantect a:visited, .add-symantect a:hover, .add-symantect a:active{ 
	color:#c74b00; 
	text-decoration: underline; 
	font-size:12px;
	font-family:Arial, Helvetica, sans-serif;
}
.add-symantect a:hover, .add-symantect a:active{ 
	color:#000; 
}
.add-symantect .box{ 
	border:#757575 solid 1px; 
	background:#FFFFFF; 
	width:200px; 
	padding:4px; 
}
.add-symantect h2{ 
	font-family:Arial, Helvetica, sans-serif; 
	font-size:16px; 
}
.add-symantect .clear{ 
	clear:both; 
	padding:0; 
	margin:0;
}
.add-symantect .name{ 
	color:#0066CC;
}
</style>

<script type='text/javascript'>
					function check_frm(frm) {
						if(frm.credentIdone.value=='') {
							alert('Please type Credential ID');
							frm.credentIdone.focus();
							return false;
						}
						if(frm.vip_acct_comment.value=='') {
							alert('Please type Note');
							frm.vip_acct_comment.focus();
							return false;
						}
						return true;
					}
				</script>
				

<script type='text/javascript'>
	window.onload = function() {
  		document.getElementById('credentIdone').focus();
	};
</script> 

<center>
<table cellpadding='0' cellspacing='3'>
	<tr>
		<td align='left' valign='top'>
			<div class='add-symantect'>
				<div class='block-l'><img src='/includes/modules/Other/Rvtwofactor/images/symantec-logo.png' alt='' width='200' height='192' /></div>
				<div class='block-r'>
		
					<form action='index.php?cmd=clientarea&action=rvlist&rvaction=twofactor&action_do=addvip' method='post' onsubmit='return check_frm(this)'>
									<br clear='all' />
                                    <div align='left'><label for='credentIdone'>Credential ID</label> </div>
									<div align='left'><input type='text' name='credentialId' id='credentIdone' class='box' autocomplete='off' /></div>
									<div align='left'>Note</div>
									<div align='left'><input type='text' name='vip_acct_comment' id='vip_acct_comment' class='box' autocomplete='off' /></div>
									<div align='left'><?php echo $save_but; ?></div>
					</form>
					<div class='clear'></div>
					<div class='clear'></div>
					<div align='left'><a href='https://m.vip.symantec.com/home.v' target='_blank'>Get VIP Access</a> </div>
				</div>
				<div style='clear:both;'></div>
			</div>
		</td>
	</tr>
</table><br />