<?php 
#@LICENSE@#
?>
<style>
table.padtable{
	padding:0;
	margin:0;
}
table.padtable td{
	line-height:25px;
	padding:5px;
	border-bottom:1px solid #bebebe;
}
</style>
<?php

if ($_SERVER['SERVER_NAME'] == 'netway.co.th')
{
	$rv2factor_label = "Netway2Factor";
} else {
	$rv2factor_label = "RV2Factor";
}

echo "<h4>".$rv2factor_label." > Event Log</h4><br />";


$oResL = RvLibs_RvGlobalStoreApi::singleton()->request('get',
							 '/vipuserinfo', array(
													'action_do' => 'viewlog_app' , 
													'appsuser_id' => $appsuser_id ,
													'vip_acct_name' => $vip_acct_fullname
											));
$oResList = (array) $oResL; 
$cnt_log = count($oResList);

if($cnt_log>0) {
	echo "<table width='100%' cellpadding='3' cellspacing=0 border='0' class='padtable'>
			<tr>
				<td align='center' class='serv_head1'>Log Date</td>
				<td align='center' class='serv_head1'>Event</td>
				<td align='center' class='serv_head1'>IP Address</td>
			</tr>";
	foreach ($oResList as $kk => $vv) {

		$log_date = date("Y-m-d H:i:s" , $vv->log_date);

		echo "<tr>
					<td>".$log_date."</td>
					<td>".$vv->log_event."</td>
					<td>".$vv->log_ip."</td>
			  </tr>";
	}
	echo "</table>";
} else {
	echo "Not has any log";
}

?>