<?php 
#@LICENSE@#
?>
<style>
input.btn, input.btn:visited, input.btn:hover, input.btn:active{ 
	color:#fff; 
	text-decoration:none;
	background:#4f4f4f; 
	display:inline; 
	border:0;
	border-radius:3px; 
	padding:5px 15px; 
	margin-right:3px; 
	width:90px; 
	white-space:nowrap; 
	cursor:pointer;
}
input.btn:hover, input.btn:active{ 
	color:#fff; 
	background:#636363; 
}
</style>

<?php

if ($_SERVER['SERVER_NAME'] == 'netway.co.th')
{
	$rv2factor_label = "Netway2Factor";
} else {
	$rv2factor_label = "RV2Factor";
}

echo "<h4>".$rv2factor_label." > Validate Credential ID</span></h4>"; 


		
				echo '

	<div class="wrap">
	
	<center>
	<br /><br />
	
	<b>Please Validate Credential ID</b>
	
	<br /><br />
	
	
	<script type="text/javascript">
	function chk_val_frm(frm) {
		if(frm.otp.value=="") {
			alert("Please type Security Code");
			frm.otp.focus();
			return false;
		}
		return true;
	}
</script>

<script type="text/javascript">
	window.onload = function() {
  document.getElementById("otp").focus();
};
</script> 							

	
	<form name="validate_cred" method="post" action="" onsubmit="return chk_val_frm(this)">
	
	<input type="hidden" name="userId" value="'.$appsuser_id.'">
	<input type="hidden" name="vip_acct_id" value="'.$vip_acct_id.'">
	<input type="hidden" name="credentialId" value="'.$credentialId.'">
	

	
	<table class="widefat fixed" cellspacing="0" style="line-height:25px;">
	<tr>
		<td align=right>Credential ID : </td>
		<td>'.$credentialId.'</td>
	</tr>
	
	<tr>
		<td align=right valign="top" style="padding-top:3px;">Security Code : </td>
		<td><input type="text" name="otp" id="otp" MAXLENGTH="6"></td>
	</tr>
	
	<tr>
		<td> </td>
		<td><input type="submit" name="validate_cred_but" value="Validate" class="btn"></td>
	</tr>
	
	</table>
	
	</form>
	
	</div>
	</center>
	
	';

?>