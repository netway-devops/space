<?php 
#@LICENSE@#
?>
<style>
table.padtable{
	padding:0;
	margin:0;
}
table.padtable td{
	line-height:25px;
	padding:5px;
	border-bottom:1px solid #bebebe;
}
</style>
<?php

if ($_SERVER['SERVER_NAME'] == 'netway.co.th')
{
	$rv2factor_label = "Netway2Factor";
} else {
	$rv2factor_label = "RV2Factor";
}

Class ReadLogFile {
	
	private $return_log;
	
	public function ReadLogFile()
	{
		//$this->return_log = $this->readfile_chunked($user_login, $filename, true);
	}

	public function readfile_chunked($user_login, $filename, $retbytes=true)
	{
		$chunksize = 1*(1024*1024); // how many bytes per chunk
		$buffer = '';
		$cnt = 0;
		$handle = fopen($filename, 'rb');
		if ($handle === false) {
			return false;
		}
		while (!feof($handle)) {
			$buffer = fread($handle, $chunksize);
			$bufferz = explode("\r\n", $buffer);
			$cnt_row = count($bufferz);
			for ($ii=0;$ii<$cnt_row;$ii++) {
				$buff = explode(",", $bufferz[$ii]);
				if ($user_login == $buff[8]) {
					$row_log .= "<tr>
       		 			   <td align='center'>".date("Y-m-d H:i:s" ,$buff[0])."</td>
       		 			   <td align='center'>".$buff[6]."</td>
       		 			   <td align='center'>".$buff[2]."</td>
       		 			   <td align='center'>".$buff[9]."</td>
       		 		  </tr>";
				}
			}
				
			ob_flush();
			flush();
			if($retbytes) {
				$cnt += strlen($buffer);
			}
		}
		$status = fclose($handle);
		return $row_log;
	}

}

echo "<h4>".$rv2factor_label." > Access Log</h4><br />";

$cpPath = explode("/" , $_SERVER['DOCUMENT_ROOT']);
$cpPathLog = "/".$cpPath[1]."/".$cpPath[2]; 
$path3 = $cpPathLog."/.rvglobalsoft/symantecvip/logs/vipAppsAccesslogs";
$strFileName = $path3."/".$appsuser_id.".log";

$oLog = new ReadLogFile();
$row_log = $oLog->readfile_chunked($user_login, $strFileName , true);

if($row_log != '') {
	echo "<table width='100%' cellpadding='3' cellspacing=0 border='0' class='padtable'>
			<tr>
				<td align='center' class='serv_head1'>Log Date</td>
				<td align='center' class='serv_head1'>Credential ID</td>
				<td align='center' class='serv_head1'>Access</td>
				<td align='center' class='serv_head1'>IP Address</td>
			</tr>";
	echo $row_log;
	echo "</table>";
} else {
	echo "Not has any access log";
}


?>