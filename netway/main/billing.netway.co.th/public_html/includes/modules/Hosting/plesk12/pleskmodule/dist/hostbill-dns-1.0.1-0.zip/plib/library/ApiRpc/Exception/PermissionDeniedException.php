<?php

namespace Modules_HostbillDns_ApiRpc\Exception;

class PermissionDeniedException extends ApiException {
    protected $_code = 1006;
}