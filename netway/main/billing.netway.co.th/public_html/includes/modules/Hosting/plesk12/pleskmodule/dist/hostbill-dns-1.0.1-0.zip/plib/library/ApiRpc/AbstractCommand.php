<?php

namespace Modules_HostbillDns_ApiRpc;

use Modules_HostbillDns_ApiRpc\Exception\ApiException;
use Modules_HostbillDns_ApiRpc\Exception\PermissionDeniedException;

abstract class AbstractCommand {

    /**
     * @var array
     */
    protected $_params;

    abstract protected function _run();

    public function __construct($params) {
        $this->_params = $params;
        if (!\pm_Session::getClient()->isAdmin())
            throw new PermissionDeniedException("Permission denied");
        $this->_checkParams();
    }

    public function run() {
        return $this->_run();
    }

    protected function _checkParams() {}

    protected function _checkRequiredParams($params) {
        $error_params = array();
        foreach ($params as $param) {
            if (!isset($this->_params[$param]))
                $error_params[] = $param;
        }

        if (!empty($error_params))
            throw new ApiException("Required parameters '" . implode(', ', $error_params) . "' are not specified");
    }

    protected function _getParam($name, $default = '') {
        return isset($this->_params[$name]) ? $this->_params[$name] : $default;
    }
}