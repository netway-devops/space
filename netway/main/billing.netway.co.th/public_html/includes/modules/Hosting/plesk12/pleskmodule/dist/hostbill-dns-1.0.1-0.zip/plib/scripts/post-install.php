<?php
// Copyright 2018. HostBill
/**
 * https://docs.plesk.com/en-US/12.5/extensions-guide/integration-with-thirdparty-dns-services.72158/
 */
pm_Loader::registerAutoload();
pm_Context::init('hostbill-dns');

try {
    if (pm_ProductInfo::isWindows()) {
        $cmd = '"' . PRODUCT_ROOT . '\bin\extension.exe"';
    } else {
        $cmd = '"' . PRODUCT_ROOT . '/bin/extension"';
    }

    $script = $cmd . ' --exec hostbill-dns hostbill-dns.php';
    $result = pm_ApiCli::call('server_dns', array('--enable-custom-backend', $script));
} catch (pm_Exception $e) {
    echo $e->getMessage() . "\n";
    exit(1);
}
exit(0);
