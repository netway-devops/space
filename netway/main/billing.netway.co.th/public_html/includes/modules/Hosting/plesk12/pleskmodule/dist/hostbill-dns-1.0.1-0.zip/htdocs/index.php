<?php
// Copyright 2018. HostBill
pm_Context::init('hostbill-dns');

$application = new pm_Application();
$application->run();
