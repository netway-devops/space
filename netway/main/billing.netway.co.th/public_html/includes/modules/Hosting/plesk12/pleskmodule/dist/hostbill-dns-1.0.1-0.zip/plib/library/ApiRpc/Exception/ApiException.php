<?php

namespace Modules_HostbillDns_ApiRpc\Exception;

/**
 * Class ApiException
 * @package Modules_HostbillDns_ApiRpc\Exception
 */
class ApiException extends \pm_Exception {

    protected $_code = 0;

    public function __construct($message, $code = 0, \Exception $previous = null) {
        $code = $code ?: $this->_code;
        parent::__construct($message, $code, $previous);
    }
}