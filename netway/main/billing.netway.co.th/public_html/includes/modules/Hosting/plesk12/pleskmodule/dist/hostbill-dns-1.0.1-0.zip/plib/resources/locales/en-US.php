<?php
// Copyright 2018. HostBill
$messages = array(
    // Pathbar
    'controllers.index.index.title' => 'HostBill DNS Helper',
    'resyncToolTitle' => 'Resync',
    'resyncToolDescription' => 'Resync all DNS zones to HostBill.',

    'addPageTitle' => 'Configure connection to HostBill',
    'howTo' => 'Add to named.conf on the remote server (config location depends on the OS of the slave server)',
    'learnMore' => 'Learn more about this tool setup',
    'masterIpLabel' => 'Plesk (master) IP address',
    'urlLabel' => 'URL to HostBill API endpoint',
    'secretLabel' => 'Secret',
    'viewLabel' => 'View',
    'slaveSaved' => 'Configuration was saved.',

    'resyncConfirmation' => 'Resync all DNS zones to HostBill?',
    'confirmationYes' => 'Yes',
    'confirmationNo' => 'No',
    'resyncDone' => 'All DNS zones were synced to HostBill.',

    'whitelistLabel'=>'Slave IPs to whitelist',

    'testConfigConfirmation' => 'Test connection to  HostBill?',
    'confirmationYes' => 'Yes',
    'confirmationNo' => 'No',
    'testConnectionOK' => 'Connection success!',
    'testConnectionFAIL' => 'Connection failed, got error: ',
    'testConfigTitle'=>'Test connection'
);
