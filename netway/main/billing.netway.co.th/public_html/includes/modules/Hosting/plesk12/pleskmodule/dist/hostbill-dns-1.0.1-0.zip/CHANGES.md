# 1.0.0 (06 June 2018)
* [+] Initial extension release
# 1.0.1 (04 December 2019)
* [+] API call *upload-file*