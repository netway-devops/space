<?php
// Copyright 2018. HostBill
class Modules_HostbillDns_API
{


    /**
     * @param $arguments
     * @param bool $verbose
     * @return bool
     * @throws Exception on connection errors, when $verbose equals true
     */
    private function _call ($arguments, $verbose = false)
    {
        $config = new Modules_HostbillDns_Config();

        $arguments = array_merge([
            'secret'=>base64_encode($config->getSecret()),
            'master'=>$config->getMasterIp(),
            'master_public'=>$config->getMasterPublicIp(),
        ],$arguments);


        $headers = [
            'Content-type' => 'application/json',

            'Cache-Control' => 'no-cache'
        ];
        $url = $config->getURL();

        if(!trim($url) || !trim($arguments['secret']))
            return false;


        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($arguments));
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        $data = curl_exec($ch);
        $err = curl_error($ch);
        $status = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);



        if ($status != 200) {
            error_log("Error code $status: $data, err: $err");
            if($verbose) {
                if($err)
                    $data.=" err: ".$err;

                throw new Exception("Error code $status: $data");
            }
            return false;
        }

        return true;
    }

    public function addZone($zone)
    {

        try {
            $this->_call( ['do'=>'addzone','zone'=>$zone]);
        } catch (Exception $e) {

        }
    }

    public function updateZone($zone)
    {
        try {
            $this->_call( ['do'=>'updatezone','zone'=>$zone]);
        } catch (Exception $e) {

        }

    }

    public function deleteZone($zone)
    {
        try {
            $this->_call( ['do'=>'rmzone','zone'=>$zone]);
        } catch (Exception $e) {

        }
    }


    public function createPTR($ptr) {
        try {
            $this->_call( ['do'=>'addptr','ptr'=>$ptr]);
        } catch (Exception $e) {

        }
    }

    public function deletePTR($ptr) {
        try {
            $this->_call( ['do'=>'rmptr','ptr'=>$ptr]);
        } catch (Exception $e) {

        }

    }

    /**
     * Check connection status
     * @return bool
     * @throws Exception
     */
    public function checkStatus()  {
        return $this->_call( ['do'=>'status'], true);
    }
}
