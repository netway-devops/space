<?php

namespace Modules_HostbillDns_ApiRpc;

use Modules_HostbillDns_ApiRpc\Exception\ApiException;

/**
 * Class Factory
 * @package Modules_HostbillDns_ApiRpc
 */
class Factory {

    public static function get($command, $params) {
        switch ($command) {
            case 'upload-file':
                return new Command\UploadFile($params);
                break;
        }

        throw new ApiException("API command {$command} is not available");
    }
}