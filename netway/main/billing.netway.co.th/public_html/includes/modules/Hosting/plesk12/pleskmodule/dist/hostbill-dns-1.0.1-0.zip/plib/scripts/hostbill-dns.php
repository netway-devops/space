<?php
// Copyright 2018. HostBill
pm_Loader::registerAutoload();
pm_Context::init('hostbill-dns');

$jsonInput = file_get_contents('php://stdin');
$data = json_decode($jsonInput,true);
if (!is_array($data)) {
    echo "Invalid json data input: $jsonInput\n";
    exit(1);
}

foreach ($data as $task) {
    $command = (string)$task['command'];
    if (!in_array($command, ['create', 'update', 'delete','deletePTRs','createPTRs','uploadFile'])) {
        continue;
    }

    if ($command == 'uploadFile') {
        if (empty($task['domain']))
            continue;
        try {
            $pm_domain = pm_Domain::getByName(trim($task['domain']));
            $domain_id = $pm_domain->getId();
            if (!$domain_id)
                continue;
            $pm_file_manager = new pm_FileManager($domain_id);
            if ($pm_file_manager->fileExists($task['file']))
                continue;

            $pm_file_manager->filePutContents($task['file'], $task['content']);

        } catch (Exception $e) {
            continue;
        }
    }

    if(in_array($command,['create', 'update', 'delete'])) {
        try {
            $pm_domain = pm_Domain::getByName(rtrim($task['zone']['name'],'.'));
            $pm_client = $pm_domain->getClient();
            $task['zone']['client_id']=$pm_client->getId();
        } catch (pm_Exception $e) {

        }
    }


    $api = new Modules_HostbillDns_API();

    switch ($command) {
        case 'create':
            $api->addZone($task['zone']);
            break;
        case 'update':
            $api->updateZone($task['zone']);
            break;
        case 'delete':
            $api->deleteZone($task['zone']);
            break;
        case 'deletePTRs':
            $api->deletePTR($task['ptr']);
            break;
        case 'createPTRs':
            $api->createPTR($task['ptr']);
            break;


    }
}
