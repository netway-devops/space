<?php
// Copyright 2018. HostBill
class Modules_HostbillDns_Config
{




    public function getURL()
    {
        return pm_Settings::get("hb-url", "");
    }


    public function getMasterIp()
    {
        return pm_Settings::get("hb-masterIp", Modules_HostbillDns_IpAddress::getDefault());
    }

    public function getMasterPublicIp()
    {
        $ipAddress =  pm_Settings::get("hb-masterIp", Modules_HostbillDns_IpAddress::getDefault());
        return Modules_HostbillDns_IpAddress::getPublic($ipAddress);
    }


    public function getSecret() {
        return pm_Settings::get("hb-secret", "");
    }


    public function getWhitelist() {
        return pm_Settings::get("hb-whitelist", "");
    }

    public function save(array $data)
    {

        $settings = ['url', 'masterIp', 'secret','whitelist'];
        foreach ($settings as $setting) {
            if (array_key_exists($setting, $data)) {
                pm_Settings::set("hb-{$setting}", $data[$setting]);
            }
        }
        if(!empty(trim($data['whitelist']))) {
            $ips = explode(',',$data['whitelist']);


            $request="<dns>
    <add_to_acl>
        <filter>";
            foreach($ips as $ip) {
                $ip = trim($ip);
                if($ip) {
                    $request.="<host>".$ip."</host>";
                }

            }
            $request.="</filter>
    </add_to_acl>
</dns>";
            pm_ApiRpc::getService('1.6.5.0')->call($request);
        }

    }





    public function remove()
    {

            $settings = ['url', 'masterIp', 'secret','whitelist'];
            foreach ($settings as $setting) {
                pm_Settings::set("hb-", null);
            }
    }
}
