<?php
// Copyright 2018. HostBill

/**
 *
 * Class Modules_HostbillDns_Form_Add
 * @see https://docs.plesk.com/en-US/onyx/extensions-reference/classes/pm_Form_Simple.html
 *
 */
class Modules_HostbillDns_Form_Add extends pm_Form_Simple
{

    var $config;

    public function init()
    {
        parent::init();

        $this->config = new Modules_HostbillDns_Config();


        $this->addElement('select', 'masterIp', array(
            'label' => $this->lmsg('masterIpLabel'),
            'multiOptions' => $this->_getIps(),
            'required' => true,
            'value'=> $this->config->getMasterIp(),
            'validators' => array(
                array('NotEmpty', true),
                array('Ip', true),
            ),
        ));
        $this->addElement('text', 'url', array(
            'label' => $this->lmsg('urlLabel'),
            'value' => $this->config->getURL(),
            'class' => 'f-large-size',
            'required' => true,
            'validators' => array(
                array('NotEmpty', true),
            ),
        ));

        $this->addElement('text', 'secret', array(
            'label' => $this->lmsg('secretLabel'),
            'value' => $this->config->getSecret(),
            'class' => 'f-large-size',
            'required' => true,
            'validators' => array(
                array('NotEmpty', true),
            ),
        ));

        $this->addElement('text', 'whitelist', array(
            'label' => $this->lmsg('whitelistLabel'),
            'value' => $this->config->getWhitelist(),
            'class' => 'f-large-size',
            'required' => false

        ));


        $this->addControlButtons(array(
            'cancelLink' => pm_Context::getBaseUrl(),
        ));
    }

    public function process()
    {
        $values = $this->getValues();
        $this->config->save($values);


    }



    private function _getIps()
    {
        return Modules_HostbillDns_IpAddress::getAvailable();
    }


}
