<?php

use Modules_HostbillDns_ApiRpc\Factory;

class Modules_HostbillDns_ApiRpc extends pm_Hook_ApiRpc {
    public function call($data) {
        $result = array();
        foreach ($data as $command => $params) {
            $result[$command] = Factory::get($command, $params)->run();
        }

        return $result;
    }
}