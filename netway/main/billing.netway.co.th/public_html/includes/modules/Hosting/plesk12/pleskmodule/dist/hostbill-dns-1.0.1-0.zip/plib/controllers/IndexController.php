<?php
// Copyright 2018. HostBill
class IndexController extends pm_Controller_Action
{
    public function init()
    {
        parent::init();

        if (!pm_Session::getClient()->isAdmin()) {
            throw new pm_Exception('Permission denied');
        }
    }

    public function indexAction()
    {
        $this->_forward('add');
    }


    public function addAction()
    {
        $this->view->pageTitle = $this->lmsg('addPageTitle');
        $this->view->uplevelLink = pm_Context::getBaseUrl();

        $form = new Modules_HostbillDns_Form_Add();

        if ($this->getRequest()->isPost() && $form->isValid($this->getRequest()->getPost())) {
            $form->process();

            $this->_status->addMessage('info', $this->lmsg('slaveSaved'));
            $this->_helper->json(array('redirect' => pm_Context::getBaseUrl()));
        }

        $this->view->form = $form;
    }


    public function testconfigAction()
    {
        if (!$this->getRequest()->isPost()) {
            throw new pm_Exception('Method POST is required');
        }
        $api = new Modules_HostbillDns_API();

        $error = '';
        try {
            $status = $api->checkStatus();

        } catch (Exception $e){

            $status = false;
            $error = $e->getMessage();
        }
        if($status) {
            $this->_status->addInfo($this->lmsg('testConnectionOK'));

        } else {
            $this->_status->addError($this->lmsg('testConnectionFAIL').$error);

        }
        $this->_redirect('/');
    }

    public function resyncAction()
    {
        if (!$this->getRequest()->isPost()) {
            throw new pm_Exception('Method POST is required');
        }

        pm_ApiCli::call('repair', ['--dns', '-sync-zones', '-y']);

        $this->_status->addInfo($this->lmsg('resyncDone'));
        $this->_redirect('/');
    }


}
