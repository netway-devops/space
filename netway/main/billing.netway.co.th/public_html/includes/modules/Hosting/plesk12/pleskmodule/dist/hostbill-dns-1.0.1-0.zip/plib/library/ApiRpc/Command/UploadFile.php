<?php

namespace Modules_HostbillDns_ApiRpc\Command;

use Modules_HostbillDns_ApiRpc\Exception\ApiException;
use Modules_HostbillDns_ApiRpc\AbstractCommand;

class UploadFile extends AbstractCommand {

    /**
     * @param string domain - domain name
     * @param string file - path to the file (e.g. api/file.pdf)
     * @param string content - file in base64
     */
    protected function _checkParams() {
        $this->_checkRequiredParams(array('domain', 'file', 'content'));
    }

    protected function _run() {
        try {
            $pm_domain = \pm_Domain::getByName(trim($this->_params['domain']));
            $domain_id = $pm_domain->getId();
            if (!$domain_id)
                throw new ApiException("Could not find domain {$this->_params['domain']}");
            $root_path = $pm_domain->getDocumentRoot();

            $pm_file_manager = new \pm_FileManager($domain_id);
            $root_path_elements = explode('/', $root_path);
            $path_elements = explode('/', $this->_params['file']);
            $element = 0;
            $path = array();

            foreach ($root_path_elements as $key => $root_path_element) {
                $path[] = $root_path_element;
                if ($root_path_element == $path_elements[$element])
                    $element++;
                elseif ($element > 0)
                    $element = 0;
            }

            for ($i = $element; $i < count($path_elements); $i++) {
                if (empty($path_elements[$i]))
                    continue;
                $path[] = $path_elements[$i];
            }

            $last_key = end(array_keys($path));

            $tmp_path = '';
            foreach ($path as $key => $path_element) {
                if ($key == $last_key) {
                    if (count(explode('.', $path_element)) > 1)
                        continue;
                }

                $tmp_path .= '/' . $path_element;
                if (!$pm_file_manager->fileExists($tmp_path))
                    $pm_file_manager->mkdir($tmp_path);
            }

            $path = implode('/', $path);
            $pm_file_manager->filePutContents($path, base64_decode($this->_params['content']));
        } catch (ApiException $e) {
            return array(
                'status' => 'error',
                'message' => $e->getMessage()
            );
        }

        return array(
            'status' => 'success',
            'message' => 'The file has been added correctly'
        );
    }
}